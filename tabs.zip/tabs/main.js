const tabs = document.getElementById('tabs'),
      content = document.querySelectorAll('.content'),
      tabsDop = document.getElementById('tabs-dop'),
      contentDop = document.querySelectorAll('.content-dop');

// Функция для смены активного класса для основных табов
const changeClass = el => {
    for(let i = 0; i < tabs.children.length; i++) {
        tabs.children[i].classList.remove('active');
    }
    el.classList.add('active');
};

// Обработчик события "Клик" для основных табов
tabs.addEventListener('click', (e) => {
    const currTab = e.target.dataset.btn;
    changeClass(e.target); // Вызов функции смены активного класса основных табов
    for(let i = 0; i < content.length; i++) {
        content[i].classList.remove('active');
        if(content[i].dataset.content === currTab) {
            content[i].classList.add('active');
        }
    }
});

// Функция для смены активного класса для дополнительных табов
const changeClassDop = el => {
    for(let i = 0; i < tabsDop.children.length; i++) {
        tabsDop.children[i].classList.remove('active');
    }
    el.classList.add('active');
};

// Обработчик события "Клик" для дополнительных табов
tabsDop.addEventListener('click', (e) => {
    const currTab = e.target.dataset.btndop;
    changeClassDop(e.target); // Вызов функции смены активного класса основных табов
    for(let i = 0; i < contentDop.length; i++) {
        contentDop[i].classList.remove('active');
        if(contentDop[i].dataset.contentdop === currTab) {
            contentDop[i].classList.add('active');
        }
    }
});